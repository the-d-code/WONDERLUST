﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WONDERLUST_PROJECT_APIs.Models.DbModels;

namespace WONDERLUST_PROJECT_APIs.Controllers
{
    public class HomeController : Controller
    {
        
    }
}
